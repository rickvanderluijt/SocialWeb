import pandas as pd
from langchain_ollama import OllamaLLM
from langchain_core.callbacks.manager import CallbackManager
from langchain_core.callbacks.streaming_stdout import StreamingStdOutCallbackHandler

# Load the SH_Artikel dataset
sh_artikel_df = pd.read_csv('ALL_toots.csv')

# Initialize the Ollama model with a callback for streaming outputs
llm = OllamaLLM(
    model="llama3.1:8b",
    num_ctx=2000,
    callbacks=[StreamingStdOutCallbackHandler()]
)

# Define a function to classify product row into Level 1 categories
def classify_to_level_1(row):
    prompt = f"""
<|start_header_id|>system<|end_header_id|>
Je bent een politiek analist. Op basis van de gegeven inhoud van het bericht, classificeer het politieke standpunt strikt als een van de volgende: 'links', 'rechts', 'midden' of 'N/B' als de classificatie onduidelijk is. Reageer uitsluitend met één van deze woorden.<|start_header_id|>gebruiker<|end_header_id|>

Inhoud van het bericht om te categoriseren:
- Gebruikersnaam: {row['Username']}
- Bericht: {row['Content']}

Reageer alleen met de categorienaam: 'links', 'rechts', 'midden' of 'N/B'.
"""
    result = llm.invoke(prompt)
    return result

# Apply the classification function to the first 10 rows of the DataFrame
sh_artikel_df['Level_1_Category'] = sh_artikel_df.iloc[:5].apply(classify_to_level_1, axis=1)

# Save the final DataFrame to CSV
sh_artikel_df.to_csv('Classified.csv', index=False)