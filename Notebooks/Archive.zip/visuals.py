import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Load the dataset
file_path = '/mnt/data/All_predictions_MajorityVote (1).csv'
data = pd.read_csv(file_path)
data['DateTime'] = pd.to_datetime(data['DateTime'])

# --- Plot 1: Monthly Political Trends ---
data['Month'] = data['DateTime'].dt.to_period('M')
monthly_data = data.groupby(['Month', 'political_standpoint']).size().unstack(fill_value=0)

plt.figure(figsize=(14, 8))
monthly_data.plot(kind='bar', stacked=True)
plt.title("Monthly Trends in Political Standpoints (2023-2025)")
plt.xlabel("Month")
plt.ylabel("Number of Posts")
plt.xticks(rotation=45)
plt.legend(title="Political Standpoint Categories", loc='upper left')
plt.grid(axis='y')
plt.tight_layout()
plt.show()

# --- Plot 2: Trends with 'n/b' ---
valid_categories = ['links', 'midden', 'rechts', 'n/b']
data_filtered = data[data['political_standpoint'].isin(valid_categories)]
data_filtered['Month'] = data_filtered['DateTime'].dt.to_period('M')
counts = data_filtered.groupby(['Month', 'political_standpoint']).size().unstack(fill_value=0)

plt.figure(figsize=(14, 8))
counts[['links', 'midden', 'rechts']].plot(kind='bar', stacked=True, color=['#FFD700', '#F46920', '#F53255'], width=0.4)
counts['n/b'].plot(kind='bar', color=['#1F77B4'], width=0.4, alpha=0.8, position=1)
plt.title("Monthly Trends Including 'n/b' (2023-2025)")
plt.xlabel("Month")
plt.ylabel("Number of Posts")
plt.xticks(rotation=45)
plt.legend(labels=['Links', 'Midden', 'Rechts', 'n/b'], title="Categories", loc='upper left')
plt.grid(axis='y')
plt.tight_layout()
plt.show()

# --- Plot 3: Hashtag Co-Occurrence ---
data['Hashtags'] = data['Content'].str.findall(r'#\w+')
top_hashtags = pd.Series([tag for tags in data['Hashtags'] for tag in tags]).value_counts().head(13).index
co_matrix = pd.DataFrame(0, index=top_hashtags, columns=top_hashtags)

for tags in data['Hashtags']:
    filtered_tags = [tag for tag in tags if tag in top_hashtags]
    for i in range(len(filtered_tags)):
        for j in range(i + 1, len(filtered_tags)):
            co_matrix.loc[filtered_tags[i], filtered_tags[j]] += 1
            co_matrix.loc[filtered_tags[j], filtered_tags[i]] += 1

plt.figure(figsize=(12, 10))
sns.heatmap(co_matrix, annot=True, fmt="d", cmap="coolwarm", cbar=True)
plt.title("Hashtag Co-Occurrence Heatmap")
plt.xlabel("Hashtags")
plt.ylabel("Hashtags")
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()

# --- Plot 4: Top 13 Hashtag Trends ---
data['Hashtags'] = data['Content'].str.findall(r'#\w+')
data_exploded = data.explode('Hashtags')
top_13 = data_exploded['Hashtags'].value_counts().head(13).index
data_top_13 = data_exploded[data_exploded['Hashtags'].isin(top_13)]
trend_data = data_top_13.groupby(['Hashtags', 'political_standpoint']).size().unstack(fill_value=0)

plt.figure(figsize=(14, 8))
trend_data[['links', 'midden', 'rechts']].plot(kind='bar', stacked=True)
plt.title("Trends for Top 13 Hashtags by Political Standpoint")
plt.xlabel("Hashtags")
plt.ylabel("Number of Posts")
plt.xticks(rotation=45)
plt.legend(title="Categories")
plt.grid(axis='y')
plt.tight_layout()
plt.show()
