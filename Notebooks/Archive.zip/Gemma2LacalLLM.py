import pandas as pd
from langchain_ollama import OllamaLLM
from langchain_core.callbacks.manager import CallbackManager
from langchain_core.callbacks.streaming_stdout import StreamingStdOutCallbackHandler

# Load the SH_Artikel dataset
sh_artikel_df = pd.read_csv('ALL_toots.csv')

# Initialize the Ollama model with a callback for streaming outputs
llm = OllamaLLM(
    model="Gemma2",
    num_ctx=2000,

    callbacks=[StreamingStdOutCallbackHandler()]
)

# Define a function to classify product row into Level 1 categories
def classify_to_level_1(row):
    prompt = f"""
<start_of_turn>user
Je bent een politiek analist. Jouw taak is om het politieke standpunt van een bericht strikt te classificeren als een van de volgende: 'links', 'rechts', 'midden' of 'N/B' als het onduidelijk is. Gebruik uitsluitend één van deze categorieën. Hieronder volgen enkele voorbeelden om te laten zien hoe berichten worden gecategoriseerd.
<end_of_turn>

<start_of_turn>user
Inhoud van het bericht om te categoriseren:
- Gebruikersnaam: helladeboo
- Bericht: "Acuut stoppen van #medicatie omdat dit niet meer wordt vergoed! Dit raakt zoveel mensen!"
<end_of_turn>
<start_of_turn>model
N/B
<end_of_turn>

<start_of_turn>user
Inhoud van het bericht om te categoriseren:
- Gebruikersnaam: RonjaBiernat
- Bericht: "Audio-documentaire: 'Geen kleine man' over de invloed van beleid op gezinnen."
<end_of_turn>
<start_of_turn>model
rechts
<end_of_turn>

<start_of_turn>user
Inhoud van het bericht om te categoriseren:
- Gebruikersnaam: ErikJonker
- Bericht: "Het kabinet was zo blij met de overeenstemming over klimaat dat het nu alles op alles zet."
<end_of_turn>
<start_of_turn>model
midden
<end_of_turn>

<start_of_turn>user
Inhoud van het bericht om te categoriseren:
- Gebruikersnaam: VoorbeeldGebruiker
- Bericht: "Goed item in acht uur journaal over nijpend tekort aan arbeidskrachten in de EU en hoe paradoxaal genoeg heleboel landen doen of ze vooral immigratie willen beperken, ik hoop dat rechtse partijkiezers ook naar het journaal kijken üòÉ#immigratie #eu"
<end_of_turn>
<start_of_turn>model
links
<end_of_turn>

<start_of_turn>user
Inhoud van het bericht om te categoriseren:
- Gebruikersnaam: {row['Username']}
- Bericht: {row['Content']}
Reageer ALLEEN met de categorienaam: 'links', 'rechts', 'midden' of 'N/B'.
<end_of_turn>
<start_of_turn>model
{{ .Response }}
<end_of_turn>
"""
    result = llm.invoke(prompt)
    return result

# Repeat the classification process 5 times and save 5 CSV files
for i in range(1, 6):  # Iterates from 1 to 5
    # Copy the DataFrame to avoid modifying the original
    df_copy = sh_artikel_df.copy()

    # Apply the classification function to all rows in the DataFrame
    df_copy['Level_1_Category'] = df_copy.apply(classify_to_level_1, axis=1)

    # Create a filename with the model name and iteration number
    output_filename = f'Classified_llama3.1_8b_iteration_{i}.csv'

    # Save the final DataFrame to a new CSV file
    df_copy.to_csv(output_filename, index=False)

    print(f"Iteration {i}: File saved as {output_filename}")